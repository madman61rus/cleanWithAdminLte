<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=mcb_leasing',
    'username' => 'root',
    'password' => 'coolroot',
    'charset' => 'utf8',
];